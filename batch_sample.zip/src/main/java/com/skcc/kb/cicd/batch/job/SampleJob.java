package com.skcc.kb.cicd.batch.job;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.skcc.kb.cicd.batch.job.dto.UserDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class SampleJob {
    @Autowired
    private JobBuilderFactory jobBuilderFactory;
    @Autowired
    private StepBuilderFactory stepBuilderFactory;
    @Autowired
    @Qualifier("sqlSession")
    private SqlSession sqlSession;
    
    @Bean
    public Job sampleJob2(){
    	//일반 리스트 조회
    	List<UserDto> userList = sqlSession.selectList("UserMapper.selectList");

    	log.info("userList : " + userList.toString());
    	
        Job sampleJob = jobBuilderFactory.get("sampleJob2")
                .start(sampleJobStep1())
                .build();

        return sampleJob;
    }

    @Bean
    public Step sampleJobStep1() {
        return stepBuilderFactory.get("sampleJobStep1")
                .tasklet((contribution, chunkContext) -> {
                    log.info("Step!");
                    return RepeatStatus.FINISHED;
                })
                .build();
    }
    
}
