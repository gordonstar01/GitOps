package com.skcc.kb.cicd.batch.job;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.batch.MyBatisBatchItemWriter;
import org.mybatis.spring.batch.MyBatisPagingItemReader;
import org.mybatis.spring.batch.builder.MyBatisBatchItemWriterBuilder;
import org.mybatis.spring.batch.builder.MyBatisPagingItemReaderBuilder;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.skcc.kb.cicd.batch.job.dto.UserDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class DbToDbJob {
    @Autowired
    private JobBuilderFactory jobBuilderFactory;
    @Autowired
    private StepBuilderFactory stepBuilderFactory;
    @Autowired
    private SqlSessionFactory sqlSessionFactory;
    
    @Bean
    public Job dbToDbJob_start(){
        Job sampleJob = jobBuilderFactory.get("dbToDbJob_start")
                .start(dbToDbJobStep1())
                .build();

        return sampleJob;
    }

    @Bean
    public Step dbToDbJobStep1() {
        return stepBuilderFactory.get("dbToDbJobStep1")
        		.<UserDto, UserDto>chunk(10)
        		.reader(dbToDbJob2reader())
        		.writer(dbToDbJob2writer())
                .build();
    }

	@Bean
    public MyBatisPagingItemReader<UserDto> dbToDbJob2reader() {
    	
        return new MyBatisPagingItemReaderBuilder<UserDto>()
                .pageSize(10)
                .sqlSessionFactory(sqlSessionFactory)
                .queryId("UserMapper.selectList")
                .build();
    }
    
    @Bean
    public MyBatisBatchItemWriter<UserDto> dbToDbJob2writer()  {
    	return  new MyBatisBatchItemWriterBuilder<UserDto>()
                .sqlSessionFactory(sqlSessionFactory)
                .statementId("UserMapper.insertUser")
                .build();
    }
}
